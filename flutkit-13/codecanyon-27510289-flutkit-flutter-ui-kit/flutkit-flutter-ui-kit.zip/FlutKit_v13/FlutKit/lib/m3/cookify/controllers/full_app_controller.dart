import 'package:flutx/flutx.dart';

class FullAppController extends FxController {
  @override
  String getTag() {
    return "full_app_controller";
  }
}
