package com.example.UIKit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
