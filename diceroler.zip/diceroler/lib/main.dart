//import 'package:chatgpt_plugin/SplashScreen.dart';
import 'package:chatgpt_plugin/dice_page1.dart';
import 'package:chatgpt_plugin/dice_page2.dart';
import 'package:chatgpt_plugin/dice_page3.dart';
import 'package:chatgpt_plugin/custom.dart';
import 'package:chatgpt_plugin/dice_page5.dart';
import 'package:chatgpt_plugin/dice_page6.dart';
import 'package:chatgpt_plugin/home_page.dart';
import 'package:flutter/material.dart';

import 'SplashScreen.dart';

void main(){
  runApp(MaterialApp(
    home: SplashScreen(),
    debugShowCheckedModeBanner: false,
  )
  );
}